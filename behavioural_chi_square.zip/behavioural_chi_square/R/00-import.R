#load tidyverse package
library(tidyverse)

#create vector of file paths to all scanner responses
files <- list.files("data-raw",
                    pattern = "R[0-8][0-9]+_showFaces3p5_.+\\.csv",
                    full.names = T)

#create vector of all subject ids
sub_ids <- unique(gsub("data-raw/|_showFaces.+\\.csv",
                       "",
                       files))

#check size of all selected files
size <- data.frame()

for (i in 1:length(files)){
  temp <- read.csv(files[i])
  temp_length <- cbind(nrow(temp), files[i])
  size <- rbind(size, temp_length)
}

colnames(size) <- c("nrows", "file")
size$nrows <- as.numeric(size$nrows)

#exclude files with less than 100 rows (false start)
newfiles <- subset(size, size$nrows>100)
files <- paste(newfiles$file)

#import raw data
raw <- data.frame()

for (i in 1:length(files)){
  temp <- read.csv(files[i])
  temp <- temp %>%
    slice(-1)
  temp$file_path <- files[i]
  raw <- rbind(raw, temp)
}
