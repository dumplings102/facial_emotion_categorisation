#calculate chi-square for each subject
results <- data.frame()

for (i in 1:length(sub_ids)){
  temp <- test_df %>%
    filter(sub_id == sub_ids[i])
  test <- chisq.test(temp$count,
                     p = temp$probability)
  p <- test$p.value
  chisq <- as.numeric(test$statistic)
  temp2 <- data.frame(cbind(p, chisq))
  temp2$sub_id <- sub_ids[i]
  results <- rbind(results, temp2)
}

#save chi-square results to "data-processed" folder
write_csv(results, "data-processed/chisq_results.csv")
