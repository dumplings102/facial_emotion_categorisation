#exclude data for which no response was made
df_filtered <- df %>%
  filter(response_key != "None")

#create chi square table of observed count and expected probability of
##correct and incorrect responses
test_df <- df_filtered %>%
  group_by(sub_id) %>%
  summarise(correct = sum(accuracy=="correct"),
            incorrect = sum(accuracy!="correct")) %>%
  pivot_longer(cols = c("correct", "incorrect"),
               names_to = "accuracy",
               values_to = "count") %>%
  mutate(probability = rep(c(0.25, 0.75),
                           times = length(sub_ids)))

#save chi-square table to "data-processed" folder
write_csv(test_df, "data-processed/chisq_table.csv")
