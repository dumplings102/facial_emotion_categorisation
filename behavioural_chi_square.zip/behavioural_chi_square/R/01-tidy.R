#select necessary variables from raw data and rename
df <- raw %>%
  select(file_path, FileName, key_resp.keys, InvertedFlag)

colnames(df) <- c("file_path",
                  "stim_path",
                  "response_key",
                  "inversion")

#assign subject ID and session start time
df <- df %>%
  extract(file_path,
          "sub_id",
          "data-raw/(R[0-9]+)_showFaces.+\\.csv")

#assign stimulus category and image ID
df <- df %>%
  extract(stim_path,
          "stimulus_category",
          "./S1/E[1-4]/SHINEd_([a-zA-Z]+)_[0-9]+\\.jpg")

#assign corresponding emotions to response keys
df <- df %>%
  mutate(response_category =
           case_when(response_key == "1" ~ "happy",
                     response_key == "2" ~ "anger",
                     response_key == "3" ~ "fear",
                     response_key == "4" ~ "neutral"))

#assign inversion labels
df <- df %>%
  mutate(inversion_label =
           case_when(inversion == "1" ~ "inverted",
                     inversion == "0" ~ "upright"))

#assign accuracy of response
df <- df %>%
  mutate(accuracy =
           case_when(response_category == stimulus_category ~ "correct",
                     response_category != stimulus_category ~ "incorrect"))

#assign factor level to variables
cnames <- names(df)
df[,cnames] <- lapply(df[,cnames], factor)
