# -*- coding: utf-8 -*-
"""
Created on Tue Feb  7 21:32:01 2023

@author: User
"""
import pandas as pd
import numpy as np

data = pd.read_csv('R5792_showFaces3p5_correct_2023_Jan_16_1638.csv')
df = pd.DataFrame(data, columns=['FileName', 'key_resp.keys']) #Narrowed two column dataframe creation

print(df)

df = df.iloc[1: , :] # removing first row

print(df)

df.loc[df['FileName'].str.contains('happy'), 'FileName'] = 'happy'
df.loc[df['FileName'].str.contains('fear'), 'FileName'] = 'fear'
df.loc[df['FileName'].str.contains('anger'), 'FileName'] = 'anger'
df.loc[df['FileName'].str.contains('neutral'), 'FileName'] = 'neutral'

print(df)

df = df.replace('None','N/A') #avoiding none being recognised containing o (not ncessary in non-behavioural example)

print(df)
df.loc[df['key_resp.keys'].str.contains('1'), 'key_resp.keys'] = 'happy'
df.loc[df['key_resp.keys'].str.contains('2'), 'key_resp.keys'] = 'anger'
df.loc[df['key_resp.keys'].str.contains('3'), 'key_resp.keys'] = 'fear'
df.loc[df['key_resp.keys'].str.contains('4'), 'key_resp.keys'] = 'neutral'

print(df)

conditions = [
    (df['key_resp.keys'] == 'N/A'),
    (df['FileName'] == df['key_resp.keys']),
    (df['FileName'] != df['key_resp.keys'])
    ]

# create a list of the values we want to assign for each condition
values = ['Null', 'Hit', 'Miss']

# create a new column and use np.select to assign values to it using our lists as arguments
df['Agreement'] = np.select(conditions, values)

print(df)


# count occurrences a particular column
occur = df.groupby(['Agreement']).size()
 
# display occurrences of a particular column
display(occur)


#Independant Emotion analysis
#Hits and Misses for happiness,

data2=df.loc[df['FileName'] == 'happy', 'Agreement']
df2 = pd.DataFrame(data2, columns=['Agreement'])
print(df2)
# count occurrences a particular column
occur2 = df2.groupby(['Agreement']).size()
 
# display occurrences of a particular column
display(occur2)

#Hits and Misses for anger,
data3=df.loc[df['FileName'] == 'anger', 'Agreement']
df3 = pd.DataFrame(data3, columns=['Agreement'])
print(df3)
# count occurrences a particular column
occur3 = df3.groupby(['Agreement']).size()
 
# display occurrences of a particular column
display(occur3)

#Hits and Misses for fear,
data4=df.loc[df['FileName'] == 'fear', 'Agreement']
df4 = pd.DataFrame(data4, columns=['Agreement'])
print(df4)

# count occurrences a particular column
occur4 = df4.groupby(['Agreement']).size()
# display occurrences of a particular column
display(occur4)

#Hits and Misses for neutral,
data5=df.loc[df['FileName'] == 'neutral', 'Agreement']
df5 = pd.DataFrame(data5, columns=['Agreement'])
print(df5)

# count occurrences a particular column
occur5 = df5.groupby(['Agreement']).size()

# display occurrences of a particular column
display(occur5)
#df = df.rename(columns={'oldName1': 'newName1', 'oldName2': 'newName2'}) for renaming dataframe columns
