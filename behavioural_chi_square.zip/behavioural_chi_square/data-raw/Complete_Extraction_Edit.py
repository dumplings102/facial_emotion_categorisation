# -*- coding: utf-8 -*-
"""
Created on Tue Feb  7 21:32:01 2023

@author: User
"""
import pandas as pd
import numpy as np

data = pd.read_csv('R5798_showFaces3p5_correct_2023_Jan_20_1544.csv')
df = pd.DataFrame(data, columns=['FileName', 'key_resp.keys']) #Narrowed two column dataframe creation



df = df.iloc[1: , :] # removing first row



df.loc[df['FileName'].str.contains('happy'), 'FileName'] = 'happy'
df.loc[df['FileName'].str.contains('fear'), 'FileName'] = 'fear'
df.loc[df['FileName'].str.contains('anger'), 'FileName'] = 'anger'
df.loc[df['FileName'].str.contains('neutral'), 'FileName'] = 'neutral'



df = df.replace('None','N/A') #avoiding none being recognised containing o (not ncessary in non-behavioural example)

print(df)
df.loc[df['key_resp.keys'].str.contains('1'), 'key_resp.keys'] = 'happy'
df.loc[df['key_resp.keys'].str.contains('2'), 'key_resp.keys'] = 'anger'
df.loc[df['key_resp.keys'].str.contains('3'), 'key_resp.keys'] = 'fear'
df.loc[df['key_resp.keys'].str.contains('4'), 'key_resp.keys'] = 'neutral'

print(df)

conditionshappy= [
    (df['key_resp.keys'] == 'N/A'),
    (df['FileName']  == df['key_resp.keys']== 'happy'), (df['FileName'] == df['key_resp.keys']== 'fear' or 'neutral' or 'anger'),
    ((df['FileName'] == 'happy') and df['FileName']!= df['key_resp.keys']), ((df['FileName'] == 'fear' or 'neutral' or 'anger') and df['FileName']!= df['key_resp.keys'])
    ]

#room for futher conditions

# create a list of the values we want to assign for each condition
values = ['Null', 'True Positve', 'True Negative', 'False Positive', 'False Negative']

# create a new column and use np.select to assign values to it using our lists as arguments
df['Agreement'] = np.select(conditionshappy, values)

print(df)